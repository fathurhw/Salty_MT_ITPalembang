-- =====================================================================
-- SALTY — Tambah approval ITM untuk Inspeksi 6 Bulanan
-- Aman diimpor berulang (tidak membuat baris ganda).
-- =====================================================================

-- 1) Tambahkan baris approval ITM (level 2) untuk checklist 6 bulanan
--    yang masih berjalan (diajukan / approve_sebagian) dan belum punya
--    baris ITM.
INSERT INTO inspection_approvals (inspection_id, role, level, status)
SELECT i.id, 'itm', 2, 'menunggu'
FROM inspections i
WHERE i.form_type = '6bulanan'
  AND i.status IN ('diajukan', 'approve_sebagian')
  AND NOT EXISTS (
      SELECT 1 FROM inspection_approvals a
      WHERE a.inspection_id = i.id AND a.role = 'itm'
  );

-- 2) Checklist 6 bulanan yang sebelumnya sudah "disetujui" tanpa ITM
--    dibiarkan selesai (riwayat tidak diubah).
