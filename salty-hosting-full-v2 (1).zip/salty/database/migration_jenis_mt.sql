-- =====================================================================
-- SALTY — Migrasi: Jenis Mobil Tangki (SPBU, APMS, Industri, RAE, Avtur)
-- Jalankan sekali pada database yang sudah terpasang, lewat phpMyAdmin.
-- Setelah ini, import database/data_mt_ngs_2026.sql untuk memasukkan data MT.
-- =====================================================================

-- 1. Kolom jenis MT pada master mobil tangki
ALTER TABLE vehicles
  ADD COLUMN jenis_mt ENUM('spbu','apms','industri','rae','avtur')
  NOT NULL DEFAULT 'spbu' AFTER jenis_tangki;

-- 2. Cegah transportir ganda saat import data (aman diabaikan bila sudah ada)
ALTER TABLE transporters ADD UNIQUE KEY uq_transporters_nama (nama);

-- 3. Perbarui view jatuh tempo agar ikut menampilkan jenis MT
DROP VIEW IF EXISTS v_due_inspections;
CREATE VIEW v_due_inspections AS
SELECT v.id, v.no_polisi, v.jenis_mt, t.nama AS transportir, v.last_inspection, v.next_inspection,
       v.stnk_no, v.stnk_berlaku, v.keur_no, v.keur_berlaku, v.tera_berlaku,
       DATEDIFF(v.next_inspection, CURDATE()) AS sisa_inspeksi,
       DATEDIFF(v.stnk_berlaku, CURDATE())    AS sisa_stnk,
       DATEDIFF(v.keur_berlaku, CURDATE())    AS sisa_keur,
       DATEDIFF(v.tera_berlaku, CURDATE())    AS sisa_tera,
       LEAST(
         COALESCE(DATEDIFF(v.next_inspection, CURDATE()), 99999),
         COALESCE(DATEDIFF(v.stnk_berlaku, CURDATE()), 99999),
         COALESCE(DATEDIFF(v.keur_berlaku, CURDATE()), 99999),
         COALESCE(DATEDIFF(v.tera_berlaku, CURDATE()), 99999)
       ) AS sisa_hari,
       CASE LEAST(
         COALESCE(DATEDIFF(v.next_inspection, CURDATE()), 99999),
         COALESCE(DATEDIFF(v.stnk_berlaku, CURDATE()), 99999),
         COALESCE(DATEDIFF(v.keur_berlaku, CURDATE()), 99999),
         COALESCE(DATEDIFF(v.tera_berlaku, CURDATE()), 99999))
         WHEN DATEDIFF(v.next_inspection, CURDATE()) THEN 'Inspeksi 6 Bulanan'
         WHEN DATEDIFF(v.stnk_berlaku, CURDATE())    THEN 'Masa Berlaku STNK'
         WHEN DATEDIFF(v.keur_berlaku, CURDATE())    THEN 'Masa Berlaku Buku KEUR'
         WHEN DATEDIFF(v.tera_berlaku, CURDATE())    THEN 'Masa Berlaku Surat Tera'
         ELSE '-' END AS sumber_jatuh_tempo
FROM vehicles v
LEFT JOIN transporters t ON t.id = v.transporter_id
WHERE v.status = 'aktif'
  AND (v.next_inspection IS NOT NULL OR v.stnk_berlaku IS NOT NULL
       OR v.keur_berlaku IS NOT NULL OR v.tera_berlaku IS NOT NULL);
