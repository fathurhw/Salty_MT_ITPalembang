<?php
// =============================================================
// SALTY — Pemasang Database Otomatis
// Buka halaman ini SEKALI setelah upload & isi config/config.php,
// lalu HAPUS file ini demi keamanan.
// =============================================================
require_once __DIR__ . '/config/config.php';

$msg = '';
$ok  = false;

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Sudah pernah terpasang?
    $cek = $pdo->query("SHOW TABLES LIKE 'users'")->rowCount();
    if ($cek > 0) {
        $ok  = true;
        $msg = 'Database sudah terpasang sebelumnya. Tidak ada yang diubah.';
    } else {
        $sqlFile = __DIR__ . '/database/install.sql';
        if (!file_exists($sqlFile)) {
            throw new Exception('File database/install.sql tidak ditemukan.');
        }
        $sql = file_get_contents($sqlFile);

        // Pecah per-statement agar aman di semua versi MySQL
        $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
        $buffer = '';
        foreach (preg_split('/\r?\n/', $sql) as $line) {
            $trim = trim($line);
            if ($trim === '' || str_starts_with($trim, '--') || str_starts_with($trim, '#')) {
                continue;
            }
            $buffer .= $line . "\n";
            if (str_ends_with(rtrim($line), ';')) {
                $stmt = trim($buffer);
                $buffer = '';
                if ($stmt !== '') {
                    // Lewati perintah CREATE DATABASE / USE (tidak diizinkan di hosting)
                    if (preg_match('/^\s*(CREATE\s+DATABASE|USE\s)/i', $stmt)) {
                        continue;
                    }
                    $pdo->exec($stmt);
                }
            }
        }
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');

        $jmlMT = (int)$pdo->query('SELECT COUNT(*) FROM vehicles')->fetchColumn();
        $ok  = true;
        $msg = "Pemasangan berhasil! $jmlMT mobil tangki sudah masuk ke database.";
    }
} catch (Throwable $e) {
    $msg = 'Gagal: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pasang Database — SALTY</title>
<style>
  body{font-family:Arial,sans-serif;background:#0f2a43;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
  .card{background:#fff;color:#123;border-radius:12px;padding:32px;max-width:520px;width:90%;box-shadow:0 10px 40px rgba(0,0,0,.4)}
  h1{font-size:20px;margin:0 0 12px;color:#0f2a43}
  .ok{background:#e7f7ec;border:1px solid #2e7d32;color:#1b5e20;padding:12px 14px;border-radius:8px}
  .err{background:#fdecea;border:1px solid #c62828;color:#b71c1c;padding:12px 14px;border-radius:8px}
  a.btn{display:inline-block;margin-top:16px;background:#0f2a43;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none}
  small{color:#667;display:block;margin-top:14px}
</style>
</head>
<body>
<div class="card">
  <h1>Pemasang Database SALTY</h1>
  <div class="<?= $ok ? 'ok' : 'err' ?>"><?= htmlspecialchars($msg) ?></div>
  <?php if ($ok): ?>
    <a class="btn" href="index.php">Buka Halaman Login</a>
    <small>Penting: hapus file <b>install.php</b> ini lewat File Manager setelah pemasangan selesai.</small>
  <?php else: ?>
    <small>Periksa kembali isi <b>config/config.php</b> (nama database, username, password), lalu refresh halaman ini.</small>
  <?php endif; ?>
</div>
</body>
</html>
